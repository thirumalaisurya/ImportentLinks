
### My Medium article on this

https://techzizou007.medium.com/image-dataset-labeling-annotation-bec3390eda2d


The 2 files ***main_auto.py*** and ***tf_object_detection.py*** above in this folder have been updated. The ***tf_object_detection.py*** script has been updated to be compatible with TensorFlow 2 and above.


### To see the changes I have made, click the link below to jump to that section on my Medium article

https://techzizou007.medium.com/image-dataset-labeling-annotation-bec3390eda2d#94d0

### Where to put these files?
Replace the above 2 scripts with the same scripts inside the OpenLabeling-master folder for OpenLabeling tool.

